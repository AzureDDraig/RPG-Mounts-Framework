package ddraig.net.azureframelib.mixin;

import ddraig.net.azureframelib.resource.AzureDynamicPackResources;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import net.minecraft.class_5352;

@Mixin(class_3283.class)
public class PackRepositoryMixin {
    @Inject(method = "discoverAvailable", at = @At("RETURN"), cancellable = true)
    private void injectDynamicPack(CallbackInfoReturnable<Map<String, class_3288>> cir) {
        Map<String, class_3288> original = cir.getReturnValue();
        if (original.containsKey(AzureDynamicPackResources.PACK_ID)) {
            return;
        }

        class_3288 pack = class_3288.method_45275(
            AzureDynamicPackResources.PACK_ID,
            class_2561.method_43470("AzureFrameLib Dynamic Resources"),
            true,
            id -> new AzureDynamicPackResources(),
            class_3264.field_14188,
            class_3288.class_3289.field_14280,
            class_5352.field_25348
        );

        if (pack != null) {
            Map<String, class_3288> modified = new HashMap<>(original);
            modified.put(AzureDynamicPackResources.PACK_ID, pack);
            cir.setReturnValue(Map.copyOf(modified));
        }
    }

    @ModifyVariable(
        method = "setSelected",
        at = @At("HEAD"),
        argsOnly = true
    )
    private Collection<String> modifySelected(Collection<String> selected) {
        if (selected != null && !selected.contains(AzureDynamicPackResources.PACK_ID)) {
            List<String> list = new ArrayList<>(selected);
            list.add(AzureDynamicPackResources.PACK_ID);
            return list;
        }
        return selected;
    }
}
