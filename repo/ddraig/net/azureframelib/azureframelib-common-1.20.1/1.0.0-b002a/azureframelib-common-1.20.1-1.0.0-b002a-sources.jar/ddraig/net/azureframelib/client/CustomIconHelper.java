package ddraig.net.azureframelib.client;

import ddraig.net.azureframelib.AzureFrameLib;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Universal custom icon scanner and dynamic silhouette / greyscale generator.
 */
public class CustomIconHelper {
    private static final Map<String, class_2960> ICONS = new ConcurrentHashMap<>();
    private static final Map<String, class_2960> SILHOUETTES = new ConcurrentHashMap<>();

    public static void clearCache() {
        ICONS.clear();
        SILHOUETTES.clear();
    }

    public static void registerIconFromDisk(String name, File file) {
        if (file == null || !file.exists() || !file.isFile()) return;
        try (InputStream is = new FileInputStream(file)) {
            class_1011 img = class_1011.method_4309(is);
            registerImage(name, img);
        } catch (Exception e) {
            AzureFrameLib.LOGGER.error("[AzureFrameLib] Failed to load icon: " + file.getName(), e);
        }
    }

    public static void registerIconFromBytes(String name, byte[] bytes) {
        if (bytes == null || bytes.length == 0) return;
        try (ByteArrayInputStream bis = new ByteArrayInputStream(bytes)) {
            class_1011 img = class_1011.method_4309(bis);
            registerImage(name, img);
        } catch (Exception e) {
            AzureFrameLib.LOGGER.error("[AzureFrameLib] Failed to register icon bytes: " + name, e);
        }
    }

    private static void registerImage(String name, class_1011 image) {
        String clean = name.toLowerCase(Locale.ROOT).replace(' ', '_');
        class_1043 normalTexture = new class_1043(image);
        class_2960 normalLoc = new class_2960(AzureFrameLib.MOD_ID, "dynamic/icons/" + clean);

        // Generate greyscale silhouette
        int w = image.method_4307();
        int h = image.method_4323();
        class_1011 silhouette = new class_1011(w, h, false);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int abgr = image.method_4315(x, y);
                int a = (abgr >> 24) & 0xFF;
                if (a > 0) {
                    int b = (abgr >> 16) & 0xFF;
                    int g = (abgr >> 8) & 0xFF;
                    int r = abgr & 0xFF;
                    int gray = (int) (0.299 * r + 0.587 * g + 0.114 * b);
                    gray = Math.max(0, Math.min(255, gray / 2 + 30));
                    int newColor = (a << 24) | (gray << 16) | (gray << 8) | gray;
                    silhouette.method_4305(x, y, newColor);
                } else {
                    silhouette.method_4305(x, y, 0);
                }
            }
        }
        class_1043 silTexture = new class_1043(silhouette);
        class_2960 silLoc = new class_2960(AzureFrameLib.MOD_ID, "dynamic/icons/" + clean + "_silhouette");

        class_310 mc = class_310.method_1551();
        if (mc != null) {
            mc.execute(() -> {
                mc.method_1531().method_4616(normalLoc, normalTexture);
                mc.method_1531().method_4616(silLoc, silTexture);
            });
        }

        ICONS.put(clean, normalLoc);
        SILHOUETTES.put(clean, silLoc);
    }

    public static class_2960 getIcon(String name, class_2960 fallback) {
        if (name == null || name.trim().isEmpty()) return fallback;
        String clean = name.toLowerCase(Locale.ROOT).replace(' ', '_');
        return ICONS.getOrDefault(clean, fallback);
    }

    public static class_2960 getSilhouette(String name, class_2960 fallback) {
        if (name == null || name.trim().isEmpty()) return fallback;
        String clean = name.toLowerCase(Locale.ROOT).replace(' ', '_');
        return SILHOUETTES.getOrDefault(clean, fallback);
    }
}
