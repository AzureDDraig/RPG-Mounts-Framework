package ddraig.net.azureframelib.client;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Helper for populating autocomplete and suggestion lists for creator screens and GUIs.
 */
public class ClientSuggestionsHelper {

    private static final List<String> CACHED_BIOMES = new CopyOnWriteArrayList<>();
    private static final List<String> CACHED_DIMENSIONS = new CopyOnWriteArrayList<>();
    private static final List<String> CACHED_SOUNDS = new CopyOnWriteArrayList<>();
    private static final List<String> CACHED_PARTICLES = new CopyOnWriteArrayList<>();
    private static final List<String> CACHED_ITEMS = new CopyOnWriteArrayList<>();
    private static final List<String> CACHED_ENTITIES = new CopyOnWriteArrayList<>();

    public static void clearCache() {
        CACHED_BIOMES.clear();
        CACHED_DIMENSIONS.clear();
        CACHED_SOUNDS.clear();
        CACHED_PARTICLES.clear();
        CACHED_ITEMS.clear();
        CACHED_ENTITIES.clear();
    }

    public static void addClientBiomes(List<String> target) {
        if (CACHED_BIOMES.isEmpty()) {
            populateBiomes();
        }
        mergeInto(target, CACHED_BIOMES);
    }

    public static void addClientDimensions(List<String> target) {
        if (CACHED_DIMENSIONS.isEmpty()) {
            populateDimensions();
        }
        mergeInto(target, CACHED_DIMENSIONS);
    }

    public static void addClientSounds(List<String> target) {
        if (CACHED_SOUNDS.isEmpty()) {
            populateSounds();
        }
        mergeInto(target, CACHED_SOUNDS);
    }

    public static void addClientParticles(List<String> target) {
        if (CACHED_PARTICLES.isEmpty()) {
            populateParticles();
        }
        mergeInto(target, CACHED_PARTICLES);
    }

    public static void addClientItems(List<String> target) {
        if (CACHED_ITEMS.isEmpty()) {
            populateItems();
        }
        mergeInto(target, CACHED_ITEMS);
    }

    public static void addClientEntities(List<String> target) {
        if (CACHED_ENTITIES.isEmpty()) {
            populateEntities();
        }
        mergeInto(target, CACHED_ENTITIES);
    }

    private static void populateBiomes() {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1687 != null) {
                var regOpt = mc.field_1687.method_30349().method_33310(class_7924.field_41236);
                if (regOpt.isPresent()) {
                    for (class_2960 loc : regOpt.get().method_10235()) {
                        CACHED_BIOMES.add(loc.toString());
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void populateDimensions() {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1687 != null) {
                var regOpt = mc.field_1687.method_30349().method_33310(class_7924.field_41241);
                if (regOpt.isPresent()) {
                    for (class_2960 loc : regOpt.get().method_10235()) {
                        CACHED_DIMENSIONS.add(loc.toString());
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void populateSounds() {
        try {
            for (class_2960 loc : class_7923.field_41172.method_10235()) {
                CACHED_SOUNDS.add(loc.toString());
            }
        } catch (Throwable ignored) {}

        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.method_1483() != null) {
                Collection<class_2960> available = mc.method_1483().method_4864();
                if (available != null) {
                    for (class_2960 loc : available) {
                        String str = loc.toString();
                        if (!CACHED_SOUNDS.contains(str)) {
                            CACHED_SOUNDS.add(str);
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}

        try {
            for (String soundId : ddraig.net.azureframelib.resource.AzureResourceManager.getDiscoveredSounds()) {
                if (!CACHED_SOUNDS.contains(soundId)) {
                    CACHED_SOUNDS.add(soundId);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void addClientAnimationSuggestions(String cleanPath, List<String> results, com.google.gson.Gson gson) {
        try {
            if (class_310.method_1551() != null) {
                class_2960 rl = cleanPath.contains(":")
                        ? new class_2960(cleanPath)
                        : new class_2960("customraces", "animations/" + cleanPath);
                var res = class_310.method_1551().method_1478().method_14486(rl);
                if (res.isPresent()) {
                    try (java.io.InputStreamReader isr = new java.io.InputStreamReader(res.get().method_14482(), java.nio.charset.StandardCharsets.UTF_8)) {
                        com.google.gson.JsonObject json = gson.fromJson(isr, com.google.gson.JsonObject.class);
                        if (json != null && json.has("animations") && json.get("animations").isJsonObject()) {
                            com.google.gson.JsonObject animsObj = json.getAsJsonObject("animations");
                            for (String key : animsObj.keySet()) {
                                if (!results.contains(key)) {
                                    results.add(key);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Throwable ignored) {}

        try {
            List<String> discovered = ddraig.net.azureframelib.resource.AzureResourceManager.getAnimationNamesForModel(cleanPath);
            for (String key : discovered) {
                if (!results.contains(key)) {
                    results.add(key);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void populateParticles() {
        try {
            for (class_2960 loc : class_7923.field_41180.method_10235()) {
                CACHED_PARTICLES.add(loc.toString());
            }
        } catch (Throwable ignored) {}
    }

    private static void populateItems() {
        try {
            for (class_2960 loc : class_7923.field_41178.method_10235()) {
                CACHED_ITEMS.add(loc.toString());
            }
        } catch (Throwable ignored) {}
    }

    private static void populateEntities() {
        try {
            for (class_2960 loc : class_7923.field_41177.method_10235()) {
                CACHED_ENTITIES.add(loc.toString());
            }
        } catch (Throwable ignored) {}
    }

    private static void mergeInto(List<String> target, List<String> source) {
        if (target == null) return;
        for (String s : source) {
            if (!target.contains(s)) {
                target.add(s);
            }
        }
    }
}
