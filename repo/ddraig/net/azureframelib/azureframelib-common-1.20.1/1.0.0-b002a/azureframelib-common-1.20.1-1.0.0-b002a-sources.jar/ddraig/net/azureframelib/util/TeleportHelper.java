package ddraig.net.azureframelib.util;

import ddraig.net.azureframelib.AzureFrameLib;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Universal safe player teleportation helper with dimension crossing,
 * warmup delay, and particle/sound integration.
 */
public class TeleportHelper {

    private static final Map<UUID, WarmupTask> ACTIVE_WARMUPS = new ConcurrentHashMap<>();

    public static class WarmupTask {
        public final class_3222 player;
        public final double startX, startY, startZ;
        public final double targetX, targetY, targetZ;
        public final String targetDimension;
        public int ticksRemaining;
        public final boolean cancelOnMove;
        public final Runnable onComplete;

        public WarmupTask(class_3222 player, double targetX, double targetY, double targetZ,
                          String targetDimension, int ticksRemaining, boolean cancelOnMove, Runnable onComplete) {
            this.player = player;
            this.startX = player.method_23317();
            this.startY = player.method_23318();
            this.startZ = player.method_23321();
            this.targetX = targetX;
            this.targetY = targetY;
            this.targetZ = targetZ;
            this.targetDimension = targetDimension;
            this.ticksRemaining = ticksRemaining;
            this.cancelOnMove = cancelOnMove;
            this.onComplete = onComplete;
        }
    }

    public static void startTeleport(class_3222 player, double targetX, double targetY, double targetZ,
                                     String targetDimension, int delayTicks, boolean cancelOnMove, Runnable onComplete) {
        if (player == null) return;
        if (delayTicks <= 0) {
            teleportDirect(player, targetX, targetY, targetZ, targetDimension);
            if (onComplete != null) onComplete.run();
            return;
        }

        ACTIVE_WARMUPS.put(player.method_5667(), new WarmupTask(player, targetX, targetY, targetZ, targetDimension, delayTicks, cancelOnMove, onComplete));
    }

    public static void tickPlayer(class_3222 player) {
        if (player == null) return;
        UUID uuid = player.method_5667();
        WarmupTask task = ACTIVE_WARMUPS.get(uuid);
        if (task == null) return;

        if (task.cancelOnMove) {
            double dx = player.method_23317() - task.startX;
            double dy = player.method_23318() - task.startY;
            double dz = player.method_23321() - task.startZ;
            if ((dx * dx + dy * dy + dz * dz) > 0.5) {
                ACTIVE_WARMUPS.remove(uuid);
                return;
            }
        }

        task.ticksRemaining--;
        if (task.ticksRemaining <= 0) {
            ACTIVE_WARMUPS.remove(uuid);
            teleportDirect(player, task.targetX, task.targetY, task.targetZ, task.targetDimension);
            if (task.onComplete != null) {
                task.onComplete.run();
            }
        }
    }

    public static boolean teleportDirect(class_3222 player, double targetX, double targetY, double targetZ, String targetDimension) {
        if (player == null) return false;
        MinecraftServer server = player.method_5682();
        if (server == null) return false;

        class_3218 targetLevel = player.method_51469();
        if (targetDimension != null && !targetDimension.isEmpty()) {
            class_5321<class_1937> dimKey = class_5321.method_29179(class_7924.field_41223, new class_2960(targetDimension));
            class_3218 resolvedLevel = server.method_3847(dimKey);
            if (resolvedLevel != null) {
                targetLevel = resolvedLevel;
            }
        }

        try {
            // Spawn departure particles and sound
            playTeleportEffects(player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321());

            player.method_14251(targetLevel, targetX, targetY, targetZ, player.method_36454(), player.method_36455());

            // Spawn arrival particles and sound
            playTeleportEffects(targetLevel, targetX, targetY, targetZ);
            return true;
        } catch (Exception e) {
            AzureFrameLib.LOGGER.error("[AzureFrameLib] Failed teleporting player " + player.method_5477().getString(), e);
            return false;
        }
    }

    public static void playTeleportEffects(class_3218 level, double x, double y, double z) {
        if (level == null) return;
        level.method_43128(null, x, y, z, class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F);
        level.method_14199(class_2398.field_11214, x, y + 1.0, z, 32, 0.5, 0.5, 0.5, 0.1);
    }
}
