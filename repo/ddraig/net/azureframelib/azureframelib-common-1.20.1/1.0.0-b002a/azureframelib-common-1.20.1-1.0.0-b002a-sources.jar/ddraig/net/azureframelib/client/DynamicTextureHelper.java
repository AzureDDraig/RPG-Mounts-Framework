package ddraig.net.azureframelib.client;

import ddraig.net.azureframelib.AzureFrameLib;
import ddraig.net.azureframelib.resource.AzureResourceManager;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_1047;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Dynamic disk texture loader.
 * Loads and registers .png textures from config folders directly into Minecraft's TextureManager.
 */
public class DynamicTextureHelper {
    public static final class_2960 DEFAULT_TEXTURE = new class_2960("minecraft", "textures/entity/cow/cow.png");
    private static final Map<String, class_2960> CACHED_TEXTURES = new ConcurrentHashMap<>();

    public static void clearCache() {
        CACHED_TEXTURES.clear();
    }

    public static class_2960 getTexture(String rawPath) {
        return getTexture(rawPath, DEFAULT_TEXTURE);
    }

    public static class_2960 getTexture(String rawPath, class_2960 fallback) {
        if (rawPath == null || rawPath.trim().isEmpty()) {
            return fallback != null ? fallback : class_1047.method_4539();
        }

        String path = rawPath.trim();

        // 1. Direct namespaced ResourceLocation in vanilla assets
        if (path.contains(":") && !path.startsWith("file:")) {
            try {
                class_2960 loc = new class_2960(path);
                class_310 mc = class_310.method_1551();
                if (mc != null && mc.method_1478() != null && mc.method_1478().method_14486(loc).isPresent()) {
                    return loc;
                }
            } catch (Exception ignored) {}
        }

        String cleanKey = AzureResourceManager.sanitizePath(path);
        if (CACHED_TEXTURES.containsKey(cleanKey)) {
            return CACHED_TEXTURES.get(cleanKey);
        }

        // 2. Search across all registered config folders
        File file = AzureResourceManager.findTextureFile(path);
        if (file != null && file.exists() && file.isFile()) {
            try (InputStream is = new FileInputStream(file)) {
                class_1011 nativeImage = class_1011.method_4309(is);
                class_1043 dynamicTexture = new class_1043(nativeImage);

                String regPath = "textures/dynamic/" + cleanKey.replace('.', '_');
                class_2960 loc = new class_2960(AzureFrameLib.MOD_ID, regPath.toLowerCase(Locale.ROOT));

                class_310 mc = class_310.method_1551();
                if (mc != null && mc.method_1531() != null) {
                    class_1044 old = mc.method_1531().method_4619(loc);
                    if (old != null) {
                        try {
                            old.close();
                        } catch (Exception ignored) {}
                    }
                    mc.method_1531().method_4616(loc, dynamicTexture);
                    CACHED_TEXTURES.put(cleanKey, loc);
                    return loc;
                }
            } catch (Throwable t) {
                AzureFrameLib.LOGGER.error("[AzureFrameLib] Failed to load dynamic disk texture from " + file.getAbsolutePath(), t);
            }
        }

        return fallback != null ? fallback : class_1047.method_4539();
    }
}
