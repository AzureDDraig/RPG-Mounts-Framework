package ddraig.net.azureframelib.client;

import java.io.InputStream;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

/**
 * Utility for extracting dominant and average colors from textures.
 */
public class ColorUtils {
    private static final Map<class_2960, Integer> DOMINANT_COLOR_CACHE = new ConcurrentHashMap<>();

    public static void clearCache() {
        DOMINANT_COLOR_CACHE.clear();
    }

    public static int getDominantColor(class_2960 textureLoc) {
        if (textureLoc == null) return 0xFFFFFF;

        if (DOMINANT_COLOR_CACHE.containsKey(textureLoc)) {
            return DOMINANT_COLOR_CACHE.get(textureLoc);
        }

        int extracted = extractDominantColor(textureLoc);
        DOMINANT_COLOR_CACHE.put(textureLoc, extracted);
        return extracted;
    }

    private static int extractDominantColor(class_2960 textureLoc) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc == null) return 0xFFFFFF;

            // 1. Try checking dynamic texture from TextureManager
            class_1044 tex = mc.method_1531().method_4619(textureLoc);
            if (tex instanceof class_1043 dynamicTex && dynamicTex.method_4525() != null) {
                return calculateAverageColor(dynamicTex.method_4525());
            }

            // 2. Try reading from ResourceManager
            if (mc.method_1478() != null) {
                Optional<class_3298> res = mc.method_1478().method_14486(textureLoc);
                if (res.isPresent()) {
                    try (InputStream is = res.get().method_14482()) {
                        class_1011 image = class_1011.method_4309(is);
                        int color = calculateAverageColor(image);
                        image.close();
                        return color;
                    }
                }
            }
        } catch (Throwable ignored) {}

        return 0xFFFFFF;
    }

    private static int calculateAverageColor(class_1011 img) {
        long totalR = 0, totalG = 0, totalB = 0;
        int count = 0;

        int width = img.method_4307();
        int height = img.method_4323();

        // Sample pixels with a stride to maintain performance
        int stepX = Math.max(1, width / 32);
        int stepY = Math.max(1, height / 32);

        for (int x = 0; x < width; x += stepX) {
            for (int y = 0; y < height; y += stepY) {
                int pixel = img.method_4315(x, y);
                int a = (pixel >> 24) & 0xFF;
                if (a > 32) { // ignore transparent pixels
                    int r = pixel & 0xFF;
                    int g = (pixel >> 8) & 0xFF;
                    int b = (pixel >> 16) & 0xFF;

                    totalR += r;
                    totalG += g;
                    totalB += b;
                    count++;
                }
            }
        }

        if (count == 0) return 0xFFFFFF;

        int avgR = (int) (totalR / count);
        int avgG = (int) (totalG / count);
        int avgB = (int) (totalB / count);

        return ((avgR & 0xFF) << 16) | ((avgG & 0xFF) << 8) | (avgB & 0xFF);
    }
}
