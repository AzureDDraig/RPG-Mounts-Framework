package ddraig.net.azureframelib.client;

import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Shared GUI rendering utilities.
 */
public class UIHelper {

    public static void drawOutline(class_332 graphics, int x, int y, int width, int height, int color) {
        graphics.method_25294(x, y, x + width, y + 1, color);
        graphics.method_25294(x, y + height - 1, x + width, y + height, color);
        graphics.method_25294(x, y + 1, x + 1, y + height - 1, color);
        graphics.method_25294(x + width - 1, y + 1, x + width, y + height - 1, color);
    }

    public static void drawPanel(class_332 graphics, int x, int y, int width, int height, int bgColor, int borderColor) {
        graphics.method_25294(x, y, x + width, y + height, bgColor);
        drawOutline(graphics, x, y, width, height, borderColor);
    }

    public static String truncate(class_327 font, String text, int maxWidth) {
        if (text == null) return "";
        if (font.method_1727(text) <= maxWidth) return text;
        int dotsWidth = font.method_1727("...");
        if (maxWidth <= dotsWidth) return "...";
        return font.method_27523(text, maxWidth - dotsWidth) + "...";
    }
}
